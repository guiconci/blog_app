##  Coursework Template ##
### CM2040 Database Networks and the Web ###

## LIBRARIES USED ##
* Bootstrap CSS - the styling of the app is done with static CSS and bootstrap from some elemtens like buttons and tables
* jQuery - Installed together with bootstrap for animation (modal fade)

## Extra npm packages ##
* No packages where instaled for usage in the app itself
* Nodemon - installed to speed up a bit the development process and avoid restarting the server all the time

## Instalation requirements ####
* No special requirements needed

